
// Both interfaces declare print(): no ambiguity, because the class provides the one implementation.
interface Printable3 {
    void print();
}

interface Showable3 {
    void print();
}

// Note: the manual's code refers to "TestTnterface1" here (a typo); it is fixed to use this class.
public class TestInterface3 implements Printable3, Showable3 {
    public void print() { System.out.println("Hello"); }

    public static void main(String args[]) {
        TestInterface3 obj = new TestInterface3();
        obj.print();
    }
}
